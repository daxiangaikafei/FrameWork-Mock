import configHelper from './config'

module.exports.config = configHelper